image-names.csv: contains information about the photos used in our study.
	google_id: image id used in the Google open image dataset version 4.
	survey_photo_no: assigned number in the survey
	bbox: bounding box (from Google dataset) that was used to crop portion of the image. The cropped version was used in our study.

survey-data.csv: contains survey data for each (cropped) photo.
	photo_no: survey_photo_no in the image-names.csv file
	pid: participant id
	all other columns contain data from the survey.